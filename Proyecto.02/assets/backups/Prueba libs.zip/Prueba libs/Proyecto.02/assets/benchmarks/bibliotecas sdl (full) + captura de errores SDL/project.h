#pragma once
#ifndef ERROR_H_
#define ERROR_H_

class project
{
};

#endif